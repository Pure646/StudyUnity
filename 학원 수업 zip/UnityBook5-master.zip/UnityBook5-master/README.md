### 절대강좌! 유니티5 - 책에서 사용하는 리소스 파일입니다.
#### Unity 5 权威讲解Unity专业开发人员讲述高效游戏制作技巧！ - Resource Download


본 자료는 개인 학습으로만 사용하시길 바랍니다. 감사합니다.
Q&A는 [www.Unity3dStudy.com](http://www.Unity3dStudy.com) 에 글을 남겨주세요.
